﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SFXAS : MonoBehaviour
{
    public AudioClip click;
    public AudioClip hit;
    public AudioClip step;
    public AudioClip win;
    public AudioClip ay;
    public AudioClip fall;
    public AudioClip gameplayloop;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
